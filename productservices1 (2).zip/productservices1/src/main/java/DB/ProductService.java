package DB;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
@Component
public interface ProductService {

	public List<Products> getProducts();
	public Products deleteProduce(String Id);
	public Products addProduce(Products product);
	
	
}
