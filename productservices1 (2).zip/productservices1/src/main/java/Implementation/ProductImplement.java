package Implementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import DB.ProductService;
import DB.Products;
import lombok.Data;
import repository.productRepo;

@Service
public class ProductImplement implements ProductService {

	@Autowired
	private productRepo productrep;
	
	@Override
	public List<Products> getProducts() {
		// TODO Auto-generated method stub
		return productrep.findAll();
	}


	@Override
	public Products deleteProduce(String Id) {
		// TODO Auto-generated method stub
		Products product= productrep.findById(Id).get();
		productrep.delete(product);
		return product;
	}

	@Override
	public Products addProduce(Products product) {
		// TODO Auto-generated method stub
		return productrep.save(product);
	}
	

}
