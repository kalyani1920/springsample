package com.springdemo1.productservices1;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Productservices1Application {

	public static void main(String[] args) {
		SpringApplication.run(Productservices1Application.class, args);
	}

}
