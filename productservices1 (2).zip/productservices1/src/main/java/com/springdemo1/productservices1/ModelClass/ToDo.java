package com.springdemo1.productservices1.ModelClass;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import DB.ProductService;
import DB.Products;
import Implementation.ProductImplement;

@RestController
@RequestMapping("/api/products")
public class ToDo {
	@Autowired
	private ProductService productservice;

	@GetMapping("/")
	public String SayHello() {
		return "Hello World";
	}

	@PutMapping("/all")
	public List<Products> getProducts() {
		return productservice.getProducts();
	}

	@GetMapping("/insert")
	public Products insert(@RequestBody Products product) {
		return productservice.addProduce(product);
	}

	@DeleteMapping("/delete/{id}")
	public Products deleteProduct(@PathVariable String id) {
		return productservice.deleteProduce(id);
	}

}
