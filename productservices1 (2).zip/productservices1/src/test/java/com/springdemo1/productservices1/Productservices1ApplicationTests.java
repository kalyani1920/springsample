package com.springdemo1.productservices1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Productservices1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
